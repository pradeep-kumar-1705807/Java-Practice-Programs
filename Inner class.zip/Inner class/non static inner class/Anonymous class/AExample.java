abstract class Button
{
	int x=10;
	
	public abstract void doThis();
}
class AZ extends() Button
{
	public void doThis()
	{
		System.out.println("Hello World");
	}}
class BZ()
class AExample extends Button
{
	public void doThis()
	{
		System.out.println("Hello World");
	}
	
	public static void main(String args[])
	{
		Button b1=new AExample();
		Button b2=new AExample();
		
	
	}
}
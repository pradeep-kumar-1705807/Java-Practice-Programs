interface Eatable
{
	void eat();
}
public class Example 
{
	public static void main(String args[])
	{
		Eatable e1=new Eatable(){
		public	void eat()
			{
				System.out.println("Chicken Chilly");
		    }  
		};
		e1.eat();
	}
}
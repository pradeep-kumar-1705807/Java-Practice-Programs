abstract class A
{
	//private abstract void fun1();
}
class Example
{
	public static void main(String args[])
	{
		int x=5;
		int y=6;
		if((x=1)==y)
		{
			System.out.print(y);
		}
		else
		System.out.print(++x);
	}
}
Pls Compile and then run the ExampleQueue.java File.
-> javac ExampleQueue.java
-> java ExampleQueue